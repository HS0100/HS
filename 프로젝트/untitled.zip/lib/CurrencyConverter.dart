import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

class CurrencyConverter extends StatefulWidget {
  @override
  _CurrencyConverterState createState() => _CurrencyConverterState();
}

class _CurrencyConverterState extends State<CurrencyConverter> {
  final TextEditingController _amountController = TextEditingController();
  String fromCurrency = 'USD';
  String toCurrency = 'KRW';
  String result = '';
  final formatter = NumberFormat('#,##0.00');

  Future<double> fetchRate(String from, String to) async {
    final url = Uri.parse('https://api.frankfurter.app/latest?from=$from&to=$to');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['rates'][to];
    } else {
      throw Exception('환율 정보를 가져오는 데 실패했습니다: ${response.statusCode}');
    }
  }

  void convertCurrency() async {
    final raw = _amountController.text.replaceAll(',', '');
    double amount = double.tryParse(raw) ?? 0;

    if (amount <= 0) {
      setState(() => result = '올바른 금액을 입력하세요.');
      return;
    }

    try {
      double rate = await fetchRate(fromCurrency, toCurrency);
      double converted = amount * rate;
      setState(() {
        result =
        '${formatter.format(amount)} $fromCurrency → ${formatter.format(converted)} $toCurrency';
      });
    } catch (e) {
      setState(() => result = 'API 오류: ${e.toString()}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          Row(children: [
            Expanded(
              child: DropdownButtonFormField<String>(
                value: fromCurrency,
                decoration: InputDecoration(labelText: '보내는 통화'),
                items: ['USD', 'KRW', 'JPY', 'EUR']
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (val) => setState(() {
                  fromCurrency = val!;
                  result = '';
                }),
              ),
            ),
            SizedBox(width: 12),
            Icon(Icons.arrow_forward),
            SizedBox(width: 12),
            Expanded(
              child: DropdownButtonFormField<String>(
                value: toCurrency,
                decoration: InputDecoration(labelText: '받는 통화'),
                items: ['USD', 'KRW', 'JPY', 'EUR']
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (val) => setState(() {
                  toCurrency = val!;
                  result = '';
                }),
              ),
            ),
          ]),
          SizedBox(height: 16),
          TextField(
            controller: _amountController,
            decoration: InputDecoration(labelText: '금액'),
            keyboardType: TextInputType.number,
          ),
          SizedBox(height: 16),
          ElevatedButton(onPressed: convertCurrency, child: Text('환산')),
          SizedBox(height: 16),
          Text(result, style: TextStyle(fontSize: 16)),
        ],
      ),
    );
  }
}