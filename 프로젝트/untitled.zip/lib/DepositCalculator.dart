import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

class DepositCalculator extends StatefulWidget {
  @override
  _DepositCalculatorState createState() => _DepositCalculatorState();
}

class _DepositCalculatorState extends State<DepositCalculator> {
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _yearsController = TextEditingController();
  final TextEditingController _interestController = TextEditingController();
  String result = '';

  final _numberFormat = NumberFormat('#,###');

  // 정수만 허용
  final integerInputFormatter = FilteringTextInputFormatter.digitsOnly;

  // 소수점 둘째 자리까지 허용
  final decimalInputFormatter = TextInputFormatter.withFunction((oldValue, newValue) {
    final text = newValue.text;
    if (text.isEmpty) return newValue;
    final regex = RegExp(r'^\d*\.?\d{0,2}$');
    return regex.hasMatch(text) ? newValue : oldValue;
  });

  void calculate() {
    final principal = double.tryParse(_amountController.text.replaceAll(',', '')) ?? 0;
    final years = double.tryParse(_yearsController.text) ?? 0;
    final rate = double.tryParse(_interestController.text) ?? 0;

    final interest = principal * (rate / 100) * years;
    final total = principal + interest;

    setState(() {
      result =
      '이자: ${_numberFormat.format(interest)}원\n총액: ${_numberFormat.format(total)}원';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16),
      child: Column(children: [
        TextField(
          controller: _amountController,
          decoration: InputDecoration(labelText: '예치금액'),
          keyboardType: TextInputType.number,
          inputFormatters: [integerInputFormatter],
        ),
        TextField(
          controller: _yearsController,
          decoration: InputDecoration(labelText: '예금기간(년)'),
          keyboardType: TextInputType.number,
          inputFormatters: [integerInputFormatter],
        ),
        TextField(
          controller: _interestController,
          decoration: InputDecoration(labelText: '연이자율'),
          keyboardType: TextInputType.numberWithOptions(decimal: true),
          inputFormatters: [decimalInputFormatter],
        ),
        SizedBox(height: 10),
        ElevatedButton(onPressed: calculate, child: Text('계산')),
        SizedBox(height: 10),
        Text(result, style: TextStyle(fontSize: 16)),
      ]),
    );
  }
}