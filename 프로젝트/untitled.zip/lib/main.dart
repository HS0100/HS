import 'package:flutter/material.dart';

import 'BMICalculator.dart';
import 'WageCalculator.dart';
import 'CurrencyConverter.dart';
import 'DepositCalculator.dart';
import 'LoanCalculator.dart';

void main() => runApp(CalculatorApp());

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '계산기 모음',
      debugShowCheckedModeBanner:false,
      theme: ThemeData(
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: Color(0xFFE8F5E9),
        appBarTheme: AppBarTheme(
          backgroundColor: Color(0xFF388E3C),
          foregroundColor: Colors.white,
        ),
      ),
      home: CalculatorHome(),
    );
  }
}

class CalculatorHome extends StatefulWidget {
  @override
  _CalculatorHomeState createState() => _CalculatorHomeState();
}

class _CalculatorHomeState extends State<CalculatorHome> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    DepositCalculator(),
    BMICalculator(),
    CurrencyConverter(),
    WageCalculator(),
    LoanCalculator(),
  ];

  final List<String> _titles = [
    '예금 계산기',
    'BMI 계산기',
    '환율 계산기',
    '임금 계산기',
    '대출 계산기',
  ];

  void _onDrawerItemTap(int index) {
    setState(() {
      _selectedIndex = index;
    });
    Navigator.pop(context); // 메뉴 닫기
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_selectedIndex]),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Color(0xFF66BB6A),
              ),
              child: Text(
                '계산기 목록',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.savings),
              title: Text('예금 계산기'),
              onTap: () => _onDrawerItemTap(0),
            ),
            ListTile(
              leading: Icon(Icons.accessibility),
              title: Text('BMI 계산기'),
              onTap: () => _onDrawerItemTap(1),
            ),
            ListTile(
              leading: Icon(Icons.currency_exchange),
              title: Text('환율 계산기'),
              onTap: () => _onDrawerItemTap(2),
            ),
            ListTile(
              leading: Icon(Icons.work),
              title: Text('임금 계산기'),
              onTap: () => _onDrawerItemTap(3),
            ),
            ListTile(
              leading: Icon(Icons.account_balance),
              title: Text('대출 계산기'),
              onTap: () => _onDrawerItemTap(4),
            ),
          ],
        ),
      ),
      body: _pages[_selectedIndex],
    );
  }
}
