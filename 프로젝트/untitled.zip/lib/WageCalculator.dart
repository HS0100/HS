import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: WageCalculator()));

class WageCalculator extends StatefulWidget {
  const WageCalculator({super.key});

  @override
  State<WageCalculator> createState() => _WageCalculatorState();
}

class _WageCalculatorState extends State<WageCalculator> {
  String selectedType = '시급';
  double hourlyWage = 0;
  double monthlyWage = 0;
  int dailyHours = 1;
  int weeklyDays = 1;
  bool useFixedWeeklyHours = false;
  double fixedWeeklyHours = 0;

  void calculateWage() {
    num weeklyHours =
    useFixedWeeklyHours ? fixedWeeklyHours : (dailyHours * weeklyDays);
    double estimatedMonthlyHours = weeklyHours * 4.345; // 평균 1개월 주 수
    setState(() {
      if (selectedType == '시급') {
        monthlyWage = hourlyWage * estimatedMonthlyHours;
      } else {
        // 월급을 입력한 상태라면 역산으로 시급을 표시
        hourlyWage = monthlyWage / estimatedMonthlyHours;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('임금 계산기')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // 시급 or 월급 선택
            DropdownButton<String>(
              value: selectedType,
              items: ['시급', '월급'].map((type) {
                return DropdownMenuItem(value: type, child: Text(type));
              }).toList(),
              onChanged: (val) {
                setState(() {
                  selectedType = val!;
                  calculateWage();
                });
              },
            ),
            const SizedBox(height: 16),

            // 시급 또는 월급 입력 필드
            TextField(
              decoration: InputDecoration(
                labelText: selectedType == '시급' ? '시급 입력 (원)' : '월급 입력 (원)',
                border: const OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
              onChanged: (val) {
                setState(() {
                  if (selectedType == '시급') {
                    hourlyWage = double.tryParse(val) ?? 0;
                  } else {
                    monthlyWage = double.tryParse(val) ?? 0;
                  }
                  calculateWage();
                });
              },
            ),
            const SizedBox(height: 16),

            // 고정 주간 근무시간 여부
            Row(
              children: [
                const Text('고정 근무시간 사용'),
                Switch(
                  value: useFixedWeeklyHours,
                  onChanged: (val) {
                    setState(() {
                      useFixedWeeklyHours = val;
                      calculateWage();
                    });
                  },
                ),
              ],
            ),
            if (useFixedWeeklyHours)
              TextField(
                decoration: const InputDecoration(
                  labelText: '근무시간 입력',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                onChanged: (val) {
                  setState(() {
                    fixedWeeklyHours = double.tryParse(val) ?? 0;
                    calculateWage();
                  });
                },
              )
            else
              Column(
                children: [
                  // 하루 근무시간 선택
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('하루 근무시간'),
                      DropdownButton<int>(
                        value: dailyHours,
                        items: List.generate(24, (i) => i + 1).map((hour) {
                          return DropdownMenuItem(
                            value: hour,
                            child: Text('$hour 시간'),
                          );
                        }).toList(),
                        onChanged: (val) {
                          setState(() {
                            dailyHours = val!;
                            calculateWage();
                          });
                        },
                      ),
                    ],
                  ),

                  // 주간 근무일 선택
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('주간 근무일'),
                      DropdownButton<int>(
                        value: weeklyDays,
                        items: List.generate(6, (i) => i + 1).map((day) {
                          return DropdownMenuItem(
                            value: day,
                            child: Text('$day 일'),
                          );
                        }).toList(),
                        onChanged: (val) {
                          setState(() {
                            weeklyDays = val!;
                            calculateWage();
                          });
                        },
                      ),
                    ],
                  ),
                ],
              ),

            const SizedBox(height: 24),

            // 계산 결과
            Text(
              selectedType == '시급'
                  ? '예상 월급: ${monthlyWage.toStringAsFixed(0)} 원'
                  : '환산 시급: ${hourlyWage.toStringAsFixed(1)} 원',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}