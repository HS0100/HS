import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class BMICalculator extends StatefulWidget {
  @override
  _BMICalculatorState createState() => _BMICalculatorState();
}

class _BMICalculatorState extends State<BMICalculator> {
  String gender = '남성';
  final heightController = TextEditingController();
  final weightController = TextEditingController();
  String result = '';

  void calculateBMI() {
    double height = double.tryParse(heightController.text) ?? 0;
    double weight = double.tryParse(weightController.text) ?? 0;

    double bmi = weight / ((height / 100) * (height / 100));
    String category;

    if (bmi < 18.5) category = '저체중';
    else if (bmi < 23) category = '정상';
    else if (bmi < 25) category = '과체중';
    else category = '비만';

    setState(() {
      result = 'BMI: ${bmi.toStringAsFixed(2)} ($category)';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16),
      child: Column(children: [
        Row(children: [
          Expanded(
            child: ListTile(
              title: Text('남성'),
              leading: Radio(value: '남성', groupValue: gender, onChanged: (val) => setState(() => gender = val!)),
            ),
          ),
          Expanded(
            child: ListTile(
              title: Text('여성'),
              leading: Radio(value: '여성', groupValue: gender, onChanged: (val) => setState(() => gender = val!)),
            ),
          ),
        ]),
        TextField(controller: heightController, decoration: InputDecoration(labelText: '신장(cm)')),
        TextField(controller: weightController, decoration: InputDecoration(labelText: '체중(kg)')),
        SizedBox(height: 10),
        ElevatedButton(onPressed: calculateBMI, child: Text('계산')),
        SizedBox(height: 10),
        Text(result),
      ]),
    );
  }
}