import 'dart:math';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class LoanCalculator extends StatefulWidget {
  @override
  _LoanCalculatorState createState() => _LoanCalculatorState();
}

class _LoanCalculatorState extends State<LoanCalculator> {
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _yearsController = TextEditingController();
  final TextEditingController _monthsController = TextEditingController();
  final TextEditingController _interestController = TextEditingController();

  final numberFormat = NumberFormat('#,###');

  String result = '';
  int selectedMethod = 0; // 0: 원리금균등, 1: 원금균등, 2: 만기일시

  void calculate() {
    double principal = double.tryParse(_amountController.text.replaceAll(',', '')) ?? 0;
    int years = int.tryParse(_yearsController.text) ?? 0;
    int months = int.tryParse(_monthsController.text) ?? 0;
    double rate = double.tryParse(_interestController.text) ?? 0;

    int totalMonths = years * 12 + months;
    if (principal <= 0 || rate < 0 || totalMonths <= 0) {
      setState(() {
        result = '입력값을 확인하세요.';
      });
      return;
    }

    double monthlyRate = rate / 12 / 100;
    double monthlyPayment = 0;
    double totalPayment = 0;
    double totalInterest = 0;

    if (selectedMethod == 0) {
      // 원리금균등
      monthlyPayment = principal * monthlyRate * pow(1 + monthlyRate, totalMonths) /
          (pow(1 + monthlyRate, totalMonths) - 1);
      totalPayment = monthlyPayment * totalMonths;
    } else if (selectedMethod == 1) {
      // 원금균등
      double principalPart = principal / totalMonths;
      for (int i = 0; i < totalMonths; i++) {
        double interestPart = (principal - (principalPart * i)) * monthlyRate;
        totalPayment += principalPart + interestPart;
      }
      monthlyPayment = totalPayment / totalMonths;
    } else {
      // 만기일시
      totalInterest = principal * monthlyRate * totalMonths;
      totalPayment = principal + totalInterest;
      monthlyPayment = totalInterest / totalMonths;
    }

    totalInterest = totalPayment - principal;

    setState(() {
      result = '''
월 상환금: ${numberFormat.format(monthlyPayment.round())} 원
총 이자: ${numberFormat.format(totalInterest.round())} 원
총 상환금: ${numberFormat.format(totalPayment.round())} 원
''';
    });
  }

  void reset() {
    _amountController.clear();
    _yearsController.clear();
    _monthsController.clear();
    _interestController.clear();
    setState(() {
      result = '';
      selectedMethod = 0;
    });
  }

  String _getRepaymentDescription() {
    switch (selectedMethod) {
      case 0:
        return '매달 동일한 금액을 상환하며, 원금과 이자를 함께 갚아나가는 방식입니다.';
      case 1:
        return '매달 동일한 원금을 갚으며, 잔액에 대한 이자를 함께 납부하는 방식입니다.';
      case 2:
        return '매달 이자만 납부하고, 만기 시 원금을 한 번에 상환하는 방식입니다.';
      default:
        return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('대출금액'),
          TextField(
            controller: _amountController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(hintText: '예: 10,000,000'),
          ),
          SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _yearsController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: '대출기간 (년)'),
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: _monthsController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: '대출기간 (월)'),
                ),
              ),
            ],
          ),
          SizedBox(height: 10),
          Text('대출금리 (%)'),
          TextField(
            controller: _interestController,
            keyboardType: TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(hintText: '예: 3.5'),
          ),
          SizedBox(height: 10),
          Text('상환방법'),
          ToggleButtons(
            isSelected: [
              selectedMethod == 0,
              selectedMethod == 1,
              selectedMethod == 2,
            ],
            onPressed: (index) => setState(() => selectedMethod = index),
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text('원리금균등'),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text('원금균등'),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text('만기일시'),
              ),
            ],
          ),
          SizedBox(height: 8),
          Text(
            _getRepaymentDescription(),
            style: TextStyle(color: Colors.grey[700], fontSize: 14),
          ),
          SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: reset,
                  child: Text('초기화'),
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: ElevatedButton(
                  onPressed: calculate,
                  child: Text('계산하기'),
                ),
              ),
            ],
          ),
          SizedBox(height: 20),
          Text(result, style: TextStyle(fontSize: 16)),
        ],
      ),
    );
  }
}