import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class WageCalculator extends StatefulWidget {
  const WageCalculator({super.key});

  @override
  _WageCalculatorState createState() => _WageCalculatorState();
}

class _WageCalculatorState extends State<WageCalculator> {
  final TextEditingController _inputController = TextEditingController();
  final TextEditingController _workHoursController =
  TextEditingController(text: '40');

  String selectedType = '시급'; // 시급 or 월급
  String result = '';
  final NumberFormat formatter = NumberFormat('#,###');
  final int minimumWage = 10030;

  void calculate() {
    double value =
        double.tryParse(_inputController.text.replaceAll(',', '')) ?? 0;
    double weeklyWork =
        double.tryParse(_workHoursController.text.replaceAll(',', '')) ?? 0;

    if (value <= 0 || weeklyWork <= 0) {
      setState(() {
        result = '입력값이 올바르지 않습니다.';
      });
      return;
    }

    // 주휴수당 포함 여부 자동 처리: 15시간 이상일 경우 포함
    double restHours = weeklyWork >= 15 ? 8 : 0;
    double totalWeeklyHours = weeklyWork + restHours;
    double monthlyHours = totalWeeklyHours * 4.345;

    if (selectedType == '시급') {
      double weeklyPay = value * totalWeeklyHours;
      double monthlyPay = value * monthlyHours;

      setState(() {
        result = '''
✅ 시급 기준 계산
📅 주급 (${totalWeeklyHours.toStringAsFixed(1)}시간): ${formatter.format(weeklyPay.round())} 원
📆 월급 (${monthlyHours.toStringAsFixed(1)}시간): ${formatter.format(monthlyPay.round())} 원
''';
      });
    } else if (selectedType == '월급') {
      double hourly = value / monthlyHours;

      setState(() {
        result = '''
✅ 월급 기준 계산
🕒 주 ${weeklyWork}시간 (자동 주휴 ${restHours}시간 포함)
💸 시급: ${formatter.format(hourly.round())} 원
''';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('시급 ↔ 월급 계산기')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('2025년 최저시급: ${formatter.format(minimumWage)} 원',
              style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),

          /// 입력 유형 선택
          DropdownButton<String>(
            value: selectedType,
            items: ['시급', '월급']
                .map((type) =>
                DropdownMenuItem(value: type, child: Text('$type 입력')))
                .toList(),
            onChanged: (value) {
              setState(() {
                selectedType = value!;
                _inputController.clear();
                result = '';
              });
            },
          ),
          const SizedBox(height: 10),

          /// 급여 입력
          TextField(
            controller: _inputController,
            decoration: InputDecoration(
              labelText: '$selectedType (원)',
              border: const OutlineInputBorder(),
            ),
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 10),

          /// 근무시간 입력
          TextField(
            controller: _workHoursController,
            decoration: const InputDecoration(
              labelText: '주 근무시간 (예: 40)',
              border: OutlineInputBorder(),
            ),
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 16),

          /// 계산 버튼
          ElevatedButton(onPressed: calculate, child: const Text('환산하기')),
          const SizedBox(height: 20),

          /// 결과 출력
          Text(result, style: const TextStyle(fontSize: 16)),
        ]),
      ),
    );
  }
}